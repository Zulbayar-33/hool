const EMP_SHEET="Employees",FIT_SHEET="FitFood",SERVICE_SHEET="ServiceFood",HOOL_SHEET="Hool",BREAKFAST_SHEET="OglooniiTsai",LOG_SHEET="Logs";
const APP_TZ="Asia/Ulaanbaatar";

function getSpreadsheet_(){const props=PropertiesService.getScriptProperties(),configured=String(props.getProperty("SPREADSHEET_ID")||props.getProperty("SPREADSHEET_URL")||"").trim();if(configured){const match=configured.match(/\/spreadsheets\/d\/([a-zA-Z0-9-_]+)/);return SpreadsheetApp.openById(match?match[1]:configured);}const active=SpreadsheetApp.getActiveSpreadsheet();if(!active)throw new Error("Script Properties дээр SPREADSHEET_ID эсвэл SPREADSHEET_URL нэмнэ үү");return active;}

function doGet(e){
  if(e&&e.parameter&&e.parameter.api==="1")return handleApi_(e);
  return ContentService.createTextOutput("AKUMA Food API ажиллаж байна");
}

function handleApi_(e){
  const callback=String(e.parameter.callback||"callback").replace(/[^a-zA-Z0-9_$]/g,"");
  let result;
  try{
    const p=JSON.parse(e.parameter.payload||"{}");
    switch(String(e.parameter.action||"")){
      case "login":result=loginUser(p.code,p.password);break;
      case "saveFood":result=saveFood(p);break;
      case "getMyTotal":result=getMyTotal(p);break;
      case "approveTotal":result=userApproveTotal(p);break;
      case "adminDashboard":requireAdmin_(p.password);result=getAdminDashboard();break;
      case "adminRemove":requireAdmin_(p.password);result=adminRemove(p);break;
      case "adminAction":requireAdmin_(p.password);result=adminAction(p);break;
      case "adminAdd":requireAdmin_(p.password);result=adminAddFood(p);break;
      default:throw new Error("API action буруу байна");
    }
  }catch(err){result={success:false,message:err.message};}
  return ContentService.createTextOutput(callback+"("+JSON.stringify(result)+");").setMimeType(ContentService.MimeType.JAVASCRIPT);
}

function setupSheets(){
  const ss=getSpreadsheet_();
  setupOneSheet_(ss,EMP_SHEET,false);[FIT_SHEET,SERVICE_SHEET,HOOL_SHEET,BREAKFAST_SHEET].forEach(n=>setupOneSheet_(ss,n,true));
  setupLogSheet_(ss);recalculateBreakfastPrices_();createTotalSheet();createGraphicSheet();
}

function requireAdmin_(password){const expected=PropertiesService.getScriptProperties().getProperty("ADMIN_PASSWORD");if(!expected)throw new Error("Apps Script Properties дээр ADMIN_PASSWORD тохируулна уу");if(String(password||"")!==expected)throw new Error("Admin нууц үг буруу байна");}

function setupOneSheet_(ss,name,withDates){
  let sh=ss.getSheetByName(name);if(!sh)sh=ss.insertSheet(name);
  if(sh.getLastRow()===0){let h=name===EMP_SHEET?["№","Код","Нууц үг","Овог","Нэр","Албан тушаал"]:["№","Овог","Нэр","Ажил үүрэг","Нийт"];
    sh.getRange(1,1,1,h.length).setNumberFormat("@").setValues([h]);styleHeader_(sh,h.length);}
  if(withDates&&!findTotalRow(sh)){const r=Math.max(sh.getLastRow()+1,2);sh.getRange(r,1).setValue("Нийт");}
}

function setupLogSheet_(ss){let sh=ss.getSheetByName(LOG_SHEET);if(!sh)sh=ss.insertSheet(LOG_SHEET);if(sh.getLastRow()===0){const h=["Огноо цаг","Үйлдэл","Ажилтны №","Хэрэглэгч","Дэлгэрэнгүй","Sheet","Мөр","Багана"];sh.getRange(1,1,1,h.length).setValues([h]);styleHeader_(sh,h.length);}}
function styleHeader_(sh,n){sh.getRange(1,1,1,n).setFontWeight("bold").setBackground("#17233c").setFontColor("white").setHorizontalAlignment("center");sh.setFrozenRows(1);}

function loginUser(code,password){
  const ss=getSpreadsheet_();let sh=ss.getSheetByName(EMP_SHEET);if(!sh){setupSheets();sh=ss.getSheetByName(EMP_SHEET);}
  const data=sh.getDataRange().getDisplayValues();
  for(let i=1;i<data.length;i++)if(String(data[i][1]).trim()===String(code||"").trim()&&String(data[i][2]).trim()===String(password||"").trim()){
    const user={no:data[i][0],code:data[i][1],ovog:data[i][3],ner:data[i][4],job:data[i][5]};writeLog_("LOGIN",user,"Амжилттай нэвтэрсэн");return{success:true,user};}
  writeLog_("LOGIN_FAILED",{no:String(code||""),ner:""},"Код эсвэл нууц үг буруу");return{success:false,message:"Код эсвэл нууц үг буруу байна"};
}

function saveFood(data){
  const lock=LockService.getScriptLock();lock.waitLock(20000);
  try{
    const type=String(data.type||"").trim();if(!["fit","service","hool","ahool","breakfast"].includes(type))throw new Error("Хоолны төрөл буруу байна");
    const sheetName=type==="service"?SERVICE_SHEET:type==="breakfast"?BREAKFAST_SHEET:(type==="hool"||type==="ahool")?HOOL_SHEET:FIT_SHEET;
    const no=String(data.no||"").trim(),ner=String(data.ner||"").trim(),date=String(data.date||"").trim(),amount=Number(data.amount||0);
    if(!no||!ner||!date)throw new Error("Мэдээлэл дутуу байна");
    if(type==="service"&&(!Number.isFinite(amount)||amount<=0))throw new Error("ServiceFood үнэ оруулна уу");
    if(type==="breakfast"&&isBreakfastClosed_()){writeLog_("BREAKFAST_CLOSED",data,"10:00 цаг өнгөрсөн тул бүртгээгүй",BREAKFAST_SHEET);return{success:false,message:"Өглөөний цайны бүртгэл 10:00 цагт хаагдсан байна"};}
    const ss=getSpreadsheet_();let sh=ss.getSheetByName(sheetName);if(!sh){sh=ss.insertSheet(sheetName);setupOneSheet_(ss,sheetName,true);}
    const col=ensureDateColumn(sh,date);let totalRow=findTotalRow(sh);if(!totalRow){totalRow=Math.max(sh.getLastRow()+1,2);sh.getRange(totalRow,1).setValue("Нийт");}
    let row=findEmployeeRow(sh,no,totalRow);if(!row){sh.insertRowBefore(totalRow);row=totalRow;totalRow++;}
    const existing=String(sh.getRange(row,col).getDisplayValue()||"").trim();if(existing){writeLog_("DUPLICATE_BLOCKED",data,sheetName+" • "+date+" • Одоо байгаа: "+existing,sheetName,row,col);return{success:false,duplicate:true,message:"Давхар бүртгэл байна: "+ner+" • "+sheetName+" • "+date};}
    const value=type==="service"?amount:type==="breakfast"?1:(isAfterCutoff_()?"Pending":1);
    sh.getRange(row,1,1,4).setValues([[no,String(data.ovog||""),ner,String(data.job||"")]]);sh.getRange(row,col).setValue(value);
    updateRowTotal(sh,row);updateTotalRow(sh);if(sheetName===BREAKFAST_SHEET)recalculateBreakfastPrices_();createTotalSheet();createGraphicSheet();writeLog_(value==="Pending"?"PENDING_CREATED":"FOOD_SAVED",data,(value==="Pending"?"Admin зөвшөөрөл хүлээж байна":value+" • "+date),sheetName,row,col);
    return{success:true,pending:value==="Pending",message:value==="Pending"?"11:30 өнгөрсөн тул Admin зөвшөөрөл хүлээж байна":sheetName+" амжилттай хадгалагдлаа"};
  }catch(err){return{success:false,message:err.message};}finally{lock.releaseLock();}
}

function isAfterCutoff_(){const hm=Utilities.formatDate(new Date(),APP_TZ,"HH:mm").split(":").map(Number);return hm[0]>11||(hm[0]===11&&hm[1]>30);}
function isBreakfastClosed_(){const hour=Number(Utilities.formatDate(new Date(),APP_TZ,"HH"));return hour>=10;}

function getAdminDashboard(){
  const ss=getSpreadsheet_(),rows=[],stats={fit:0,service:0,hool:0,breakfast:0,breakfastMoney:0,totalFood:0,totalMoney:0,all:0,pending:0,period:getCurrentPeriod_().label};
  [FIT_SHEET,SERVICE_SHEET,HOOL_SHEET,BREAKFAST_SHEET].forEach(name=>{const sh=ss.getSheetByName(name);if(!sh)return;const data=sh.getDataRange().getDisplayValues();if(data.length<2)return;
    for(let r=1;r<data.length;r++){if(String(data[r][0]).trim()==="Нийт")continue;for(let c=4;c<data[0].length;c++){const v=String(data[r][c]||"").trim();if(!v||data[0][c]==="Нийт"||!isDateInCurrentPeriod_(data[0][c]))continue;rows.push({sheet:name,row:r+1,col:c+1,no:data[r][0],ovog:data[r][1],ner:data[r][2],job:data[r][3],date:data[0][c],value:v,pending:v==="Pending"});stats.all++;if(v==="Pending")stats.pending++;const n=Number(v)||0;if(name===FIT_SHEET)stats.fit+=n;if(name===SERVICE_SHEET)stats.service+=n;if(name===HOOL_SHEET)stats.hool+=n;if(name===BREAKFAST_SHEET)stats.breakfast+=n;}}}
  );stats.breakfastMoney=stats.breakfast*12000;stats.totalFood=stats.fit+stats.hool;stats.totalMoney=(stats.totalFood*15000)+stats.service;rows.sort((a,b)=>b.col-a.col||b.row-a.row);return{success:true,rows,stats,employees:getAdminEmployees_(),logs:getRecentLogs_(80)};
}

function getAdminEmployees_(){const ss=getSpreadsheet_(),found={};const emp=ss.getSheetByName(EMP_SHEET);if(emp&&emp.getLastRow()>=2){const d=emp.getRange(2,1,emp.getLastRow()-1,6).getDisplayValues();d.forEach(r=>{const no=String(r[0]||r[1]||"").trim();if(no&&r[4])found[no]={no:no,ovog:r[3]||"",ner:r[4]||"",job:r[5]||""};});}ss.getSheets().forEach(sh=>{if([EMP_SHEET,FIT_SHEET,SERVICE_SHEET,HOOL_SHEET,BREAKFAST_SHEET,TOTAL_SHEET,LOG_SHEET,GRAPHIC_SHEET].includes(sh.getName())||sh.getLastRow()<2)return;const maxCols=Math.min(sh.getLastColumn(),12),maxRows=Math.min(sh.getLastRow(),5),top=sh.getRange(1,1,maxRows,maxCols).getDisplayValues();let headerRow=-1,headers=[];for(let r=0;r<top.length;r++){if(top[r].map(x=>String(x).trim()).includes("Код")){headerRow=r+1;headers=top[r].map(x=>String(x).trim());break;}}if(headerRow<0)return;const codeCol=headers.indexOf("Код"),ovogCol=headers.indexOf("Овог"),nerCol=headers.indexOf("Нэр"),jobCol=headers.findIndex(x=>x==="Албан тушаал"||x==="Ажил үүрэг"||x==="Ажил үүрэг "||x==="А/тушаал ");if(codeCol<0||nerCol<0)return;const count=Math.min(Math.max(sh.getLastRow()-headerRow,0),1500);if(!count)return;const data=sh.getRange(headerRow+1,1,count,maxCols).getDisplayValues();data.forEach(r=>{const no=String(r[codeCol]||"").trim(),ner=String(r[nerCol]||"").trim();if(no&&ner&&!found[no])found[no]={no:no,ovog:ovogCol>=0?r[ovogCol]||"":"",ner:ner,job:jobCol>=0?r[jobCol]||"":""};});});return Object.keys(found).map(k=>{const x=found[k];x.label=x.no+" • "+x.ovog+" "+x.ner+" • "+x.job;return x;}).sort((a,b)=>String(a.no).localeCompare(String(b.no),"mn",{numeric:true}));}

function adminAddFood(p){const lock=LockService.getScriptLock();lock.waitLock(20000);try{const type=String(p.type||""),map={fit:FIT_SHEET,service:SERVICE_SHEET,hool:HOOL_SHEET,breakfast:BREAKFAST_SHEET},sheetName=map[type];if(!sheetName)return{success:false,message:"Хоолны төрөл буруу байна"};const employees=getAdminEmployees_(),emp=employees.find(x=>String(x.no)===String(p.employeeNo));if(!emp)return{success:false,message:"Ажилтан олдсонгүй"};const date=String(p.date||"").trim(),quantity=Math.max(1,Number(p.quantity)||1),amount=Number(p.amount)||0;if(!date)return{success:false,message:"Огноо сонгоно уу"};if(type==="service"&&amount<=0)return{success:false,message:"ServiceFood үнийн дүн оруулна уу"};const ss=getSpreadsheet_();let sh=ss.getSheetByName(sheetName);if(!sh){setupOneSheet_(ss,sheetName,true);sh=ss.getSheetByName(sheetName);}const col=ensureDateColumn(sh,date);let totalRow=findTotalRow(sh),row=findEmployeeRow(sh,emp.no,totalRow);if(!row){sh.insertRowBefore(totalRow);row=totalRow;}const existing=String(sh.getRange(row,col).getDisplayValue()||"").trim();if(existing){writeLog_("ADMIN_DUPLICATE_BLOCKED",{no:emp.no,ovog:emp.ovog,ner:emp.ner},sheetName+" • "+date+" • Одоо байгаа: "+existing,sheetName,row,col);return{success:false,duplicate:true,message:"Давхар бүртгэл байна: "+emp.ovog+" "+emp.ner+" • "+sheetName+" • "+date};}sh.getRange(row,1,1,4).setValues([[emp.no,emp.ovog,emp.ner,emp.job]]);sh.getRange(row,col).setValue(type==="service"?amount:quantity);updateRowTotal(sh,row);updateTotalRow(sh);if(sheetName===BREAKFAST_SHEET)recalculateBreakfastPrices_();createTotalSheet();createGraphicSheet();writeLog_("ADMIN_MANUAL_ADD",{no:emp.no,ovog:emp.ovog,ner:emp.ner},sheetName+" • "+date+" • "+(type==="service"?amount+"₮":quantity),sheetName,row,col);return{success:true,message:emp.ovog+" "+emp.ner+" — "+sheetName+" амжилттай нэмэгдлээ"};}catch(err){return{success:false,message:err.message};}finally{lock.releaseLock();}}

function adminRemove(p){const allowed=[FIT_SHEET,SERVICE_SHEET,HOOL_SHEET,BREAKFAST_SHEET];if(!allowed.includes(String(p.sheet)))return{success:false,message:"Sheet буруу байна"};const sh=getSpreadsheet_().getSheetByName(p.sheet);if(!sh)return{success:false,message:"Sheet олдсонгүй"};const row=Number(p.row),col=Number(p.col);if(row<2||col<5||row>sh.getLastRow()||col>sh.getLastColumn())return{success:false,message:"Мөр/багана буруу байна"};const old=sh.getRange(row,col).getDisplayValue();sh.getRange(row,col).clearContent();updateRowTotal(sh,row);updateTotalRow(sh);if(p.sheet===BREAKFAST_SHEET)recalculateBreakfastPrices_();createTotalSheet();createGraphicSheet();writeLog_("ADMIN_REMOVE",{no:sh.getRange(row,1).getDisplayValue(),ner:"Admin"},p.sheet+" • "+old,p.sheet,row,col);return{success:true,message:"Устгалаа"};}

function adminAction(p){const allowed=[FIT_SHEET,HOOL_SHEET];if(!allowed.includes(String(p.sheet)))return{success:false,message:"Зөвхөн FitFood/Хоол Pending зөвшөөрнө"};const sh=getSpreadsheet_().getSheetByName(p.sheet),row=Number(p.row),col=Number(p.col);if(!sh||String(sh.getRange(row,col).getDisplayValue()).trim()!=="Pending")return{success:false,message:"Pending бүртгэл олдсонгүй"};const value=p.action==="approve"?1:p.action==="reject"?"Rejected":null;if(value===null)return{success:false,message:"Үйлдэл буруу"};sh.getRange(row,col).setValue(value);updateRowTotal(sh,row);updateTotalRow(sh);createTotalSheet();createGraphicSheet();writeLog_(p.action==="approve"?"ADMIN_APPROVED":"ADMIN_REJECTED",{no:sh.getRange(row,1).getDisplayValue(),ner:"Admin"},p.sheet,p.sheet,row,col);return{success:true,message:p.action==="approve"?"Зөвшөөрлөө":"Татгалзлаа"};}

function getCurrentPeriod_(){const now=new Date(Utilities.formatDate(new Date(),APP_TZ,"yyyy-MM-dd'T'HH:mm:ss"));let start,end;if(now.getDate()>=26){start=new Date(now.getFullYear(),now.getMonth(),26);end=new Date(now.getFullYear(),now.getMonth()+1,25);}else{start=new Date(now.getFullYear(),now.getMonth()-1,26);end=new Date(now.getFullYear(),now.getMonth(),25);}return{start:start,end:end,label:Utilities.formatDate(start,APP_TZ,"yyyy.MM.dd")+" – "+Utilities.formatDate(end,APP_TZ,"yyyy.MM.dd")};}
function isDateInCurrentPeriod_(value){const p=getCurrentPeriod_(),text=String(value||"").trim();let d;if(/^\d{4}-\d{1,2}-\d{1,2}$/.test(text)){const a=text.split("-").map(Number);d=new Date(a[0],a[1]-1,a[2]);}else{const a=normalizeDate(text).split("/").map(Number);if(a.length!==2)return false;let year=p.start.getFullYear();if(a[0]<p.start.getMonth()+1)year=p.end.getFullYear();d=new Date(year,a[0]-1,a[1]);}return d>=p.start&&d<=p.end;}

function writeLog_(action,user,detail,sheet,row,col){const ss=getSpreadsheet_();setupLogSheet_(ss);ss.getSheetByName(LOG_SHEET).appendRow([new Date(),action,String(user.no||""),[user.ovog,user.ner].filter(Boolean).join(" "),String(detail||""),sheet||"",row||"",col||""]);}
function getRecentLogs_(limit){const sh=getSpreadsheet_().getSheetByName(LOG_SHEET);if(!sh||sh.getLastRow()<2)return[];const start=Math.max(2,sh.getLastRow()-limit+1),v=sh.getRange(start,1,sh.getLastRow()-start+1,8).getDisplayValues();return v.reverse().map(x=>({time:x[0],action:x[1],user:x[3]||x[2],detail:x[4]}));}

function ensureDateColumn(sh,date){const h=sh.getRange(1,1,1,sh.getLastColumn()).getDisplayValues()[0],target=String(date);for(let i=0;i<h.length;i++)if(String(h[i])===target)return i+1;let total=h.indexOf("Нийт")+1;if(!total){total=sh.getLastColumn()+1;sh.getRange(1,total).setValue("Нийт");}sh.insertColumnBefore(total);sh.getRange(1,total).setNumberFormat("@").setValue(target);return total;}
function normalizeDate(v){if(v instanceof Date)return(v.getMonth()+1)+"/"+v.getDate();const t=String(v||"").trim();if(/^\d{4}-\d{1,2}-\d{1,2}$/.test(t)){const p=t.split("-");return Number(p[1])+"/"+Number(p[2]);}if(t.includes("/")){const p=t.split("/");return Number(p[p.length-2])+"/"+Number(p[p.length-1]);}return t;}
function findEmployeeRow(sh,no,totalRow){if(totalRow<=2)return null;const v=sh.getRange(2,1,totalRow-2,1).getDisplayValues();for(let i=0;i<v.length;i++)if(String(v[i][0]).trim()===String(no).trim())return i+2;return null;}
function findTotalRow(sh){if(sh.getLastRow()<1)return null;const v=sh.getRange(1,1,sh.getLastRow(),1).getDisplayValues();for(let i=0;i<v.length;i++)if(String(v[i][0]).trim()==="Нийт")return i+1;return null;}
function updateRowTotal(sh,row){const h=sh.getRange(1,1,1,sh.getLastColumn()).getDisplayValues()[0],tc=h.indexOf("Нийт")+1;if(!tc)return;sh.getRange(row,tc).setFormula(`=SUM(E${row}:${getColumnLetter(tc-1)}${row})`).setNumberFormat("0");}
function updateTotalRow(sh){const h=sh.getRange(1,1,1,sh.getLastColumn()).getDisplayValues()[0],tc=h.indexOf("Нийт")+1;if(!tc)return;let tr=findTotalRow(sh);if(!tr){tr=Math.max(sh.getLastRow()+1,2);sh.getRange(tr,1).setValue("Нийт");}sh.getRange(tr,1).setValue("Нийт");sh.getRange(tr,2,1,3).clearContent();for(let c=5;c<=tc;c++){if(tr<=2)sh.getRange(tr,c).setValue(0);else{const l=getColumnLetter(c);sh.getRange(tr,c).setFormula(`=SUM(${l}2:${l}${tr-1})`).setNumberFormat("0");}}sh.getRange(tr,1,1,tc).setFontWeight("bold").setBackground("#fff2cc");}
function getColumnLetter(c){let s="";while(c>0){const t=(c-1)%26;s=String.fromCharCode(t+65)+s;c=(c-t-1)/26;}return s;}

function recalculateBreakfastPrices_(){const sh=getSpreadsheet_().getSheetByName(BREAKFAST_SHEET);if(!sh)return;let h=sh.getRange(1,1,1,sh.getLastColumn()).getDisplayValues()[0],totalCol=h.indexOf("Нийт")+1;if(!totalCol)return;let priceCol=h.indexOf("Нийт үнэ")+1;if(!priceCol){priceCol=sh.getLastColumn()+1;sh.getRange(1,priceCol).setValue("Нийт үнэ");}const totalRow=findTotalRow(sh),tl=getColumnLetter(totalCol),pl=getColumnLetter(priceCol);if(!totalRow)return;for(let r=2;r<totalRow;r++)sh.getRange(r,priceCol).setFormula(`=${tl}${r}*12000`).setNumberFormat("#,##0₮");sh.getRange(totalRow,priceCol).setFormula(totalRow>2?`=SUM(${pl}2:${pl}${totalRow-1})`:"=0").setNumberFormat("#,##0₮");}
